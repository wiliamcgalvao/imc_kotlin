package com.example.imcnew

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var peso = findViewById(R.id.edPeso) as EditText
        var altura = findViewById(R.id.edAltura) as EditText
        var resultado = findViewById(R.id.edResultado) as EditText
        var descricao = findViewById(R.id.edDescricao) as EditText
        var btncalcular = findViewById(R.id.btnCalcular) as Button


        btncalcular.setOnClickListener {
            var peso1 = peso.text.toString().toFloat();
            var altura1 = altura.text.toString().toFloat();

            var resultado1 = (peso1 / (altura1 * altura1));

            if (resultado1 < 18.5) {
                descricao.setText("Baixo Peso")
            } else
                if (resultado1 < 25) {
                    descricao.setText("Peso Adequado")
                } else
                    if (resultado1 < 30) {
                        descricao.setText("Sobrepeso")
                    } else
                        descricao.setText("Obesidade")

         resultado.setText(resultado1.toString())

            }
    }
}